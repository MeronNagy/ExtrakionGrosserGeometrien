package net.ohdm;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

import javax.swing.plaf.synth.SynthScrollBarUI;
/**
 * Main Class containing algorithm for project
 * TODO: rewrite into Methods
 */
public class Main {
	/**
	 * Runs algorithm
	 * @param args
	 */
	public static void main(String[] args) {
		//Lines die aus .json gelesen werden
		ArrayList<LineString> lines = new ArrayList<LineString>();
		//Die tatsächlichen Boundaries mit "Deutschland" im Namen
		ArrayList<LineString> boundaries = new ArrayList<LineString>();
		//GeoJSONReader
		GeoJSONReader jsonReader = new GeoJSONReader();
		//Gibt an ob die line mit dem gleichen Index eine boundary ist.
		Boolean[] boundary;
		//Gibt an ob die Line schon geprüft wurde, wenn true wird diese nicht mehr benötigt
		Boolean[] lineChecked;
		
		//DB Connection
		//PostgreSQLJDBC.run();
		
		//Import der Linien
		try {
			lines = jsonReader.readFile("raw.json");
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Connecting smaller lines");
		//Verbindet Linien die nur einen Partner haben miteinander
		for(int i = 0; i < lines.size(); i++) {
			Point iHead = lines.get(i).getHead();
			Point iTail = lines.get(i).getTail();
			int headCounter = 0;
			int tailCounter = 0;
			int headIndex = i;
			int tailIndex = i;
			boolean headAppendTail = false;
			boolean tailAppendHead = false;
			for(int j = 0; j < lines.size(); j++) {
				Point jHead = lines.get(j).getHead();
				Point jTail = lines.get(j).getTail();
				if(!(i == j)) {
					if(iHead.equals(jHead)) {
						headCounter++;
						headIndex = j;
					}
					if(iHead.equals(jTail)) {
						headCounter++;
						headAppendTail = true;
						headIndex = j;
					}
					if(iTail.equals(jHead)) {
						tailCounter++;
						tailAppendHead = true;
						tailIndex = j;
					}
					if(iTail.equals(jTail)) {
						tailCounter++;
						tailIndex = j;
					}
				}
			}
			LineString headLine = lines.get(headIndex);
			LineString tailLine = lines.get(tailIndex);
			if(headCounter == 1) {
				if(!headAppendTail) {
					headLine.reverseOrder();
				}
				headLine.getLineString().remove(headLine.getLineString().size() - 1);
				lines.get(i).appendHead(headLine);
				if(headLine.getName() == null || headLine.getName() == "null"|| lines.get(i).getName().contains(headLine.getName())) {
					
				}else {
					lines.get(i).setName(lines.get(i).getName() + "?" + headLine.getName());
				}
			}
			if(tailCounter == 1) {
				if(!tailAppendHead) {
					tailLine.reverseOrder();
				}
				tailLine.getLineString().remove(0);
				lines.get(i).appendTail(tailLine);
				if(tailLine.getName() == null || tailLine.getName() == "null" || lines.get(i).getName().contains(tailLine.getName())) {
					
				}else {
					lines.get(i).setName(lines.get(i).getName() + "?" + tailLine.getName());
				}
			}		
			if(headCounter == 1) {
				lines.remove(headLine);
				i = i -1;
			}
			if(tailCounter == 1) {
				lines.remove(tailLine);
				i = i -1;
			}
			
		}
		System.out.println(lines.size());
		System.out.println("Lines connected");
	}	
}